# Jupiter2 X100用 HPL 実行バイナリ

MPIとOpenBLASを静的リンクしたRISC-V ELFです。MPIの別途インストールは不要です。
MPIランチャーとhydra_pmi_proxyは必ず本配布物の組み合わせを使用してください。
OSの標準libc/libmと `/lib/ld-linux-riscv64-lp64d.so.1` は必要です。
glibc 2.38以降（ELFで確認）。Bianbu/Ubuntuの該当環境で使用してください。
Python 3.11以降を使用します。ビルド済み実行ではtar展開機能は使用しません。

```sh
tar -xzf hpl-jupiter2-riscv64.tar.gz
cd hpl-jupiter2-riscv64
./run-hpl --smoke            # 小規模、8 MPI ranks / X100 CPU 0-7
python3 hpl.py plan          # 32 GiB上限で現在のメモリから最大Nを計算
./run-hpl                    # 最大Nで測定
# 比較用の固定問題サイズ：
N=12000 ./run-hpl
```

既定：NB=192、P=2、Q=4、CPU_LIST=0-7、BLASは1 thread。
RESERVE_GIB=2、AVAILABLE_RESERVE_GIB=1。32 GiBが全て見える理想条件ではN=61440。
実際はMemTotal/MemAvailableから小さくなる場合があります。
`results/<UTC>/`にパラメーター・メモリ計画・MPIログ・残差判定を保存します。
HPL.datの手編集ではなく、環境変数 N/NB/P/Q/CPU_LIST で変更してください。
A100へstock ZVL256Bを移動したり、CPU0-15を混成使用したりしないでください。

MPI=MPICH4.3.2 ch3:sock、OpenBLAS0.3.34 RISCV64_ZVL256B、HPL2.3、LP64、FP64。
これはJupiter2の性能保証や最大Nの実機検証完了を意味しません。
検証範囲とソースはリポジトリ benchmarks/hpl/README.md を参照してください。

This product includes software developed at the University of Tennessee, Knoxville, Innovative Computing Laboratory.
